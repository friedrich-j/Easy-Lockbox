package com.emc.clb;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.codegrid.commons.security.SecureProperties;
import org.codegrid.commons.utils.EclipseHelper;

public class LockBox {
	
	// D2Method.passphrase
	
	protected final Logger _log = Logger.getLogger(getClass());
	
	private SecureProperties _props = new SecureProperties();
	
	public LockBox(String sFilePath, String sPassphrase) throws IOException {
		_log.debug("<init>: file path = " + sFilePath);
		_props.load(new FileInputStream(sFilePath));
		if(_props.encryptAllProperties()) {
			_log.debug("<init>: self-encrypting all keys");
			_props.store(new FileOutputStream(sFilePath), "");
			
			if(EclipseHelper.isManagedByEclipse()) {
				File f = EclipseHelper.getSourceFile(new File(sFilePath));
				if(f != null)
					_props.store(new FileOutputStream(f), null);
			}
		}
	}
	
	
	public String retrieveItemAsText(String sKey) {
		return _props.getProperty(sKey);
	}
	
	public void closeLockbox() {
	}

}
